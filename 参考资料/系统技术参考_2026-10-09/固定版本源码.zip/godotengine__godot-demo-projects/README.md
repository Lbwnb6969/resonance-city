# Godot demo projects

Each folder containing a `project.godot` file is a demo project meant to
be used with [Godot Engine](https://godotengine.org), the open source
2D and 3D game engine.

## Godot versions

- The [`master`](https://github.com/godotengine/godot-demo-projects) branch is compatible with Godot's `master` development branch (next 4.x release).
- The [`3.x`](https://github.com/godotengine/godot-demo-projects/tree/3.x) branch is compatible with Godot's `3.x` development branch (next 3.x release).
- The other branches are compatible with the matching stable versions of Godot.
  - [Click here](https://github.com/godotengine/godot-demo-projects/branches) to see all branches.
  - For example, the [`2.1`](https://github.com/godotengine/godot-demo-projects/tree/2.1)
    branch is for demos compatible with Godot 2.1.x.

## Importing demos

To import all demos at once in the project manager:

- Clone this repository or [download a ZIP archive](https://github.com/godotengine/godot-demo-projects/archive/master.zip).
  - If you've downloaded a ZIP archive, extract it somewhere.
- Open the Godot project manager and click the **Scan** button on the right.
- Choose the path to the folder containing all demos.
- All demos should now appear in the project manager.

Alternatively, you can download individual demos from the
[Asset Store](https://store.godotengine.org/publisher/godot-foundation/),
either from the website or within Godot's project manager.

## Try the demos in your browser

Most of the demos are exported to GitHub Pages. They can be viewed
[here](https://godotengine.github.io/godot-demo-projects/).

> [!NOTE]
>
> The performance of Godot in a browser is lower than natively on
> desktop or mobile. For the best performance, consider downloading
> the demos and running them with a native version of the Godot editor.

## Useful links

- [Main website](https://godotengine.org)
- [Source code](https://github.com/godotengine/godot)
- [Documentation](https://docs.godotengine.org/en/stable/)
- [Community hub](https://godotengine.org/community/)
- [TPS demo](https://github.com/godotengine/tps-demo)

## License

Those demos are distributed under the terms of the MIT license, as
described in the [LICENSE.md](LICENSE.md) file.
