#include "engine/instrument_processor.h"

#include <barelymusician.h>

#include <algorithm>
#include <atomic>
#include <cassert>
#include <cmath>
#include <cstdint>

#include "core/constants.h"
#include "core/control.h"
#include "dsp/sample_generators.h"

namespace barely {

void InstrumentProcessor::SetControl(uint32_t instrument_index, BarelyInstrumentControlType type,
                                     float value) noexcept {
  auto& params = engine_.instrument_params[instrument_index];
  switch (type) {
    case BarelyInstrumentControlType_kGain:
      params.voice_params.gain = value * value;
      break;
    case BarelyInstrumentControlType_kPitchShift:
      params.pitch_shift = value;
      params.osc_increment = std::pow(2.0f, params.osc_pitch_shift + params.pitch_shift) *
                             kReferenceFreq / engine_.sample_rate;
      params.slice_increment = std::pow(2.0f, params.pitch_shift) / engine_.sample_rate;
      break;
    case BarelyInstrumentControlType_kStereoPan:
      params.voice_params.stereo_pan = value;
      break;
    case BarelyInstrumentControlType_kAttack:
      params.adr.SetAttack(engine_.sample_rate, value);
      break;
    case BarelyInstrumentControlType_kDecay:
      params.adr.SetDecay(engine_.sample_rate, value);
      break;
    case BarelyInstrumentControlType_kSustain:
      params.voice_params.sustain = value * value;
      break;
    case BarelyInstrumentControlType_kRelease:
      params.adr.SetRelease(engine_.sample_rate, value);
      break;
    case BarelyInstrumentControlType_kSliceMode:
      params.slice_mode = static_cast<BarelySliceMode>(value);
      break;
    case BarelyInstrumentControlType_kOscMix:
      params.voice_params.osc_mix = value;
      break;
    case BarelyInstrumentControlType_kOscMode:
      params.osc_mode = static_cast<BarelyOscMode>(value);
      break;
    case BarelyInstrumentControlType_kOscNoiseMix:
      params.voice_params.osc_noise_mix = value;
      break;
    case BarelyInstrumentControlType_kOscPitchShift:
      params.osc_pitch_shift = value;
      params.osc_increment = std::pow(2.0f, params.osc_pitch_shift + params.pitch_shift) *
                             kReferenceFreq / engine_.sample_rate;
      break;
    case BarelyInstrumentControlType_kOscShape:
      params.voice_params.osc_shape = value;
      break;
    case BarelyInstrumentControlType_kOscSkew:
      params.voice_params.osc_skew = value * kOscSkewRange;
      break;
    case BarelyInstrumentControlType_kCrushDepth:
      params.voice_params.bit_crusher_range = std::pow(2.0f, (1.0f - value) * 15.0f);
      break;
    case BarelyInstrumentControlType_kCrushRate:
      params.voice_params.bit_crusher_increment = std::min(
          2.0f * GetFrequency(1.0f - value, 0.5f * engine_.sample_rate) / engine_.sample_rate,
          1.0f);
      break;
    case BarelyInstrumentControlType_kDistortionMix:
      params.voice_params.distortion_amount = value;
      break;
    case BarelyInstrumentControlType_kDistortionDrive: {
      static constexpr float kDistortionDriveRange = 19.0f;
      params.voice_params.distortion_drive = 1.0f + kDistortionDriveRange * value;
    } break;
    case BarelyInstrumentControlType_kDelaySend:
      params.voice_params.delay_send = value;
      break;
    case BarelyInstrumentControlType_kReverbSend:
      params.voice_params.reverb_send = value;
      break;
    case BarelyInstrumentControlType_kSidechainSend:
      params.voice_params.sidechain_send = value;
      break;
    case BarelyInstrumentControlType_kFilterCutoff:
      params.voice_params.filter_params.SetCutoff(engine_.sample_rate, value);
      break;
    case BarelyInstrumentControlType_kFilterResonance:
      params.voice_params.filter_params.SetResonance(value);
      break;
    case BarelyInstrumentControlType_kFilterTone:
      params.voice_params.filter_params.SetTone(value);
      break;
    case BarelyInstrumentControlType_kRetrigger:
      params.should_retrigger = static_cast<bool>(value);
      break;
    case BarelyInstrumentControlType_kVoiceCount: {
      const uint32_t new_voice_count = static_cast<uint32_t>(value);
      uint32_t active_voice_count = 0;
      uint32_t active_voice_index = params.first_voice_index;
      while (active_voice_index != kInvalidIndex && active_voice_count < new_voice_count) {
        active_voice_index = engine_.GetVoice(active_voice_index).next_voice_index;
        ++active_voice_count;
      }
      // Release the previously active voices beyond the new voice count.
      while (active_voice_index != kInvalidIndex) {
        auto& voice = engine_.GetVoice(active_voice_index);
        if (voice.prev_voice_index != kInvalidIndex) {
          engine_.GetVoice(voice.prev_voice_index).next_voice_index = kInvalidIndex;
          voice.prev_voice_index = kInvalidIndex;
        }
        const uint32_t next_voice_index = voice.next_voice_index;
        voice.next_voice_index = kInvalidIndex;
        engine_.voice_pool.Release(active_voice_index);
        active_voice_index = next_voice_index;
      }
      params.voice_count = new_voice_count;
    } break;
    default:
      assert(!"Invalid control type");
      return;
  }
}

void InstrumentProcessor::SetNoteControl(uint32_t instrument_index, float pitch,
                                         BarelyNoteControlType type, float value) noexcept {
  const auto& params = engine_.instrument_params[instrument_index];
  uint32_t voice_index = params.first_voice_index;
  while (voice_index != kInvalidIndex) {
    const auto& voice = engine_.GetVoice(voice_index);
    if (voice.pitch == pitch && voice.envelope.IsOn()) {
      break;
    }
    voice_index = voice.next_voice_index;
  }
  if (voice_index == kInvalidIndex) {
    return;
  }
  auto& voice = engine_.GetVoice(voice_index);
  switch (type) {
    case BarelyNoteControlType_kGain:
      voice.note_params.gain = value * value;
      if (voice.envelope.IsStartFrame()) {
        voice.params.gain *= voice.note_params.gain;
      }
      break;
    case BarelyNoteControlType_kPitchShift:
      voice.pitch_shift = value;
      voice.UpdatePitchIncrements(engine_.GetSlice(voice.instrument_index, voice.slice_index));
      break;
    default:
      assert(!"Invalid note control type");
      break;
  }
}

void InstrumentProcessor::SetNoteOff(uint32_t instrument_index, float pitch) noexcept {
  const auto& params = engine_.instrument_params[instrument_index];
  uint32_t voice_index = params.first_voice_index;
  while (voice_index != kInvalidIndex) {
    const auto& voice = engine_.GetVoice(voice_index);
    if (voice.pitch == pitch && voice.envelope.IsOn()) {
      break;
    }
    voice_index = voice.next_voice_index;
  }
  if (voice_index == kInvalidIndex) {
    return;
  }
  auto& voice = engine_.GetVoice(voice_index);
  if (params.first_slice_index == kInvalidIndex || params.slice_mode != BarelySliceMode_kOnce) {
    voice.envelope.Stop(params.adr, voice.params.sustain);
  } else {
    voice.stop_on_slice_end = true;
  }
}

void InstrumentProcessor::SetNoteOn(uint32_t instrument_index, float pitch) noexcept {
  auto& params = engine_.instrument_params[instrument_index];
  if (const uint32_t voice_index = AcquireVoice(params, pitch); voice_index != kInvalidIndex) {
    auto& voice = engine_.GetVoice(voice_index);
    voice.instrument_index = instrument_index;
    voice.slice_index = engine_.SelectSlice(instrument_index, params.first_slice_index, pitch);
    voice.Start(params, engine_.GetSlice(instrument_index, voice.slice_index), pitch);
  }
}

void InstrumentProcessor::SetSampleData(uint32_t instrument_index,
                                        uint32_t first_slice_index) noexcept {
  engine_.queued_sample_data_counts[instrument_index].fetch_sub(1, std::memory_order_acq_rel);
  auto& params = engine_.instrument_params[instrument_index];
  params.first_slice_index = first_slice_index;
  uint32_t active_voice_index = params.first_voice_index;
  while (active_voice_index != kInvalidIndex) {
    auto& voice = engine_.GetVoice(active_voice_index);
    voice.slice_index =
        engine_.SelectSlice(instrument_index, params.first_slice_index, voice.pitch);
    voice.UpdatePitchIncrements(engine_.GetSlice(instrument_index, voice.slice_index));
    active_voice_index = voice.next_voice_index;
  }
}

uint32_t InstrumentProcessor::AcquireVoice(InstrumentParams& params, float pitch) noexcept {
  uint32_t current_voice_index = params.first_voice_index;
  uint32_t last_voice_index = current_voice_index;
  uint32_t oldest_active_voice_index = current_voice_index;
  uint32_t active_voice_count = 0;
  while (current_voice_index != kInvalidIndex) {
    auto& voice = engine_.GetVoice(current_voice_index);
    if (voice.pitch == pitch && (params.should_retrigger || voice.envelope.IsOn())) {
      const uint32_t retrigger_voice_index = current_voice_index;
      current_voice_index = params.first_voice_index;
      do {
        auto& timestamp_voice = engine_.GetVoice(current_voice_index);
        ++timestamp_voice.timestamp;
        current_voice_index = timestamp_voice.next_voice_index;
      } while (current_voice_index != kInvalidIndex);
      return retrigger_voice_index;
    }
    if (voice.timestamp > engine_.GetVoice(oldest_active_voice_index).timestamp) {
      oldest_active_voice_index = current_voice_index;
    }
    ++voice.timestamp;
    ++active_voice_count;
    last_voice_index = current_voice_index;
    current_voice_index = voice.next_voice_index;
  }

  // Try to acquire a new voice.
  if (engine_.voice_pool.CanAcquire() && active_voice_count < params.voice_count) {
    const uint32_t new_voice_index = engine_.voice_pool.Acquire();
    VoiceState& new_voice = engine_.GetVoice(new_voice_index);
    new_voice.prev_voice_index = last_voice_index;
    new_voice.next_voice_index = kInvalidIndex;
    if (last_voice_index != kInvalidIndex) {
      engine_.GetVoice(last_voice_index).next_voice_index = new_voice_index;
    } else {
      params.first_voice_index = new_voice_index;
    }
    return new_voice_index;
  }

  // No voices are available to acquire, steal the oldest active voice.
  return oldest_active_voice_index;
}

}  // namespace barely
