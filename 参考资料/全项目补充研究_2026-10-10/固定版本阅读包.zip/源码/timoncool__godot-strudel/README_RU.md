<div align="center">

# Strudel for Godot

**Живой код Strudel внутри Godot — вставьте код, написанный в браузере, без единой правки и услышьте его в своей игре.**

[![License](https://img.shields.io/github/license/timoncool/godot-strudel?style=flat-square)](LICENSE)
[![Stars](https://img.shields.io/github/stars/timoncool/godot-strudel?style=flat-square)](https://github.com/timoncool/godot-strudel/stargazers)
[![Last Commit](https://img.shields.io/github/last-commit/timoncool/godot-strudel?style=flat-square)](https://github.com/timoncool/godot-strudel/commits)
[![Godot](https://img.shields.io/badge/Godot-4.7-478cbf?style=flat-square)](https://godotengine.org)

**[English](README.md)** · **[Русский](README_RU.md)**

![Strudel for Godot](docs/screenshots/hero.png)

</div>

Strudel for Godot — это **порт движка паттернов Strudel на GDScript**: паттерны, mini-нотация, тональные функции, сэмплер, синтезы, эффекты и планировщик с точностью до отсчёта, целиком внутри движка. Музыка пишется кодом в [strudel.cc](https://strudel.cc) или [bulka.app](https://bulka.app), а потом тот же самый текст вставляется в игру. Ни нативных бинарников, ни сети, ни сборки: чистый GDScript, ставится как любой аддон и работает везде, где работает Godot.

Он существует потому, что музыку игры, описанную своим форматом, нельзя услышать вне игры. Со Strudel вы сочиняете в браузере, слышите каждое изменение сразу и везёте в игру ровно тот же код.

## Возможности

- **Код Strudel вставляется без правок** — `const`, стрелочные функции, `$:`, цепочки, строки mini-нотации работают ровно так, как написаны
- **Совпадение доказано замером** — все **32 трека сообщества** из коллекции Strudel, 143 из 144 эталонных выражений и целый трек из 2449 событий дают **побитово те же** события, что живой Strudel; охват — **213 функций из 213 и 499 параметров из 499**; см. [docs/COMPARISON.md](docs/COMPARISON.md)
- **Точное время** — позиции событий считаются дробями, а не плавающей точкой, поэтому доли не уплывают на длинных формах
- **Планировщик с точностью до отсчёта** — часы это счётчик кадров звука, а не `_process`, поэтому просадка кадров не сбивает ритм
- **Свои сэмплы** — укажите папку; читаются карты формата Strudel и многосэмплированные инструменты
- **Пустой банк — не ошибка** — без единого сэмпла всё играет синтезом
- **Живые изменения** — паттерн и темп меняются на ходу, без щелчка и без сброса такта
- **Музыка ведёт игру** — сигнал приходит на каждое событие паттерна со всеми его параметрами
- **Чистый GDScript** — без GDExtension и бинарников под платформы; работает в собранных сборках Windows, Linux, Android и Web

## Быстрый старт

1. **Установка** — скопируйте `addons/strudel/` в свой проект и включите **Strudel** в *Проект → Настройки проекта → Плагины*.

2. **Три строки**

   ```gdscript
   var music := StrudelPlayer.new()
   add_child(music)
   music.play('s("bd sd*2, ~ hh")')
   ```

3. **Свой код** — всё, что написано в Strudel или Булке, едет как есть:

   ```gdscript
   music.play("""
   setcpm(120/4)
   $: stack(
     s("bd ~ bd ~"),
     s("hh*8").gain(0.35),
     n("0 2 4 <6 5>").scale("C4:minor").s("triangle").room(0.4)
   )
   """)
   ```

## Использование

### Игра слушает музыку

```gdscript
music.event_played.connect(func(value: Dictionary):
    if value.get("s") == "bd":
        camera.shake(0.2)
)
```

`value` — полный словарь параметров события: `s`, `note`, `gain`, `pan`, `speed` и всё остальное, что задал паттерн.

### Живые изменения

```gdscript
music.set_code('s("bd*4, hh*16")')   # такт идёт дальше, щелчка нет
music.set_cycles_per_second(0.75)     # темп меняется на месте
```

### Свои сэмплы

Укажите в `samples_path` папку с файлами `.wav` либо папку с картами формата Strudel (`.json`). Имена подпапок становятся именами инструментов: `kicks/01.wav` доступен как `s("kicks")`, а `s("kicks:1")` возьмёт второй файл.

### Сборка паттернов из GDScript

Строка — главный вход, но паттерн можно собрать и напрямую:

```gdscript
var beat := StrudelPattern.stack([
    StrudelMini.mini("bd sd"),
    StrudelMini.mini("hh*8").gain(0.3),
])
music.set_pattern(beat)
```

## Настройки

| Свойство | Что делает |
|---|---|
| `code` | Код Strudel. Присваивание на ходу меняет паттерн вживую |
| `samples_path` | Папка с `.wav` и картами сэмплов. Пусто — только синтез |
| `cycles_per_minute` | Темп. `setcpm(...)` в самом коде сильнее |
| `bus` | Шина вывода. Своих шин плагин не заводит и чужих не трогает |
| `lookahead` | На сколько секунд вперёд считаются события |
| `max_voices` | Предел голосов. Сверх него голоса вытесняются — и это считается, а не молчит |
| `master_limiter` | Мягкое ограничение. Выключено, потому что в Strudel лимитера тоже нет |

## Что такое Strudel

[Strudel](https://strudel.cc) — язык живого кодирования музыки: ритм, гармония и эффекты пишутся короткими выражениями, которые правятся прямо во время звучания. Это порт [TidalCycles](https://tidalcycles.org) на JavaScript, работает в любом браузере, ставить ничего не нужно.

[Булка](https://bulka.app) — форк Strudel со встроенным помощником и MCP-сервером; в ней удобно **сочинить** трек, прежде чем отдавать его игре. Плагин написан по Булке и сверен с ней событие в событие.

Ни то, ни другое для работы плагина не требуется — но писать музыку там, где слышишь каждое изменение сразу, а потом вставлять результат в Godot, это и есть тот круг, ради которого он сделан.

## Документация

- [docs/SYNTAX.md](docs/SYNTAX.md) — что поддержано, чего нет и что иначе
- [docs/COMPARISON.md](docs/COMPARISON.md) — чем доказано совпадение, с числами
- [docs/PORTING-RULES.md](docs/PORTING-RULES.md) — правила, по которым делался перенос
- [NOTICE.md](NOTICE.md) — происхождение и что значит лицензия AGPL для вашего проекта

## Примеры

| Пример | Что показывает |
|---|---|
| `examples/01_minimal_beat` | Случай в три строки |
| `examples/02_own_samples` | Своя папка сэмплов в формате карт Strudel |
| `examples/03_game_reacts` | Картинка игры, ведомая событиями паттерна |
| `examples/04_full_track` | Целый трек из шестнадцати секций, перенесённый без правок |
| `examples/05_community_tunes` | Тридцать два трека сообщества из коллекции Strudel — переключаются пробелом |
| `examples/07_repl` | Плеер живого кода: вставил код Strudel — слышно его и видно события с осциллографом |
| `examples/08_rhythm` | Лид ведёт игрок: движок играет всё остальное, ноты партии приходят по нажатию |

## Другие проекты [@timoncool](https://github.com/timoncool)

| Проект | Описание |
|---------|-------------|
| [Булка](https://bulka.app) | Форк Strudel с ИИ-помощником и MCP-сервером |
| [ACE-Step Studio](https://github.com/timoncool/ACE-Step-Studio) | Портативный генератор музыки — песни с вокалом, каверы, видео |

## Благодарности

Strudel сделали Alex McLean и участники проекта. Этот плагин — порт их работы, а не самостоятельная реализация; каждый перенесённый файл называет свой оригинал в шапке.

## Поддержать автора

Я создаю опенсорс софт и занимаюсь исследованиями в области ИИ. Большая часть всего, что я делаю, находится в открытом доступе. Ваши пожертвования позволяют мне создавать и исследовать больше, не отвлекаясь на поиск еды для продолжения существования =)

**[Все способы поддержки](https://github.com/timoncool/ACE-Step-Studio/blob/master/DONATE.md)** | **[dalink.to/nerual_dreming](https://dalink.to/nerual_dreming)** | **[boosty.to/neuro_art](https://boosty.to/neuro_art)**

- **BTC:** `1E7dHL22RpyhJGVpcvKdbyZgksSYkYeEBC`
- **ETH (ERC20):** `0xb5db65adf478983186d4897ba92fe2c25c594a0c`
- **USDT (TRC20):** `TQST9Lp2TjK6FiVkn4fwfGUee7NmkxEE7C`

## Star History

<a href="https://github.com/timoncool/godot-strudel/stargazers">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="docs/stars-dark.svg" />
   <source media="(prefers-color-scheme: light)" srcset="docs/stars-light.svg" />
   <img alt="Star History Chart" src="docs/stars-light.svg" />
 </picture>
</a>

## Лицензия

**AGPL-3.0-or-later** — та же, что у Strudel, потому что это его порт. Если вы распространяете игру вместе с плагином, на игру ложатся те же условия. Прочтите [NOTICE.md](NOTICE.md) до того, как плагин попадёт в сборку.
