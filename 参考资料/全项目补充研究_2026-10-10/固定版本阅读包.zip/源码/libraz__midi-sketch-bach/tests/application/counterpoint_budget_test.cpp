#include "composer/counterpoint_budget.h"

#include <gtest/gtest.h>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <iterator>
#include <string>
#include <utility>
#include <vector>

#include "application/composition_service.h"
#include "composer/form_director.h"
#include "composer/validation.h"
#include "composer/validator.h"
#include "core/basic_types.h"

namespace bach::application {
namespace {

// Every form the product path ships.
constexpr FormType kShippedForms[] = {
    FormType::Fugue,
    FormType::PreludeAndFugue,
    FormType::TrioSonata,
    FormType::ChoralePrelude,
    FormType::ToccataAndFugue,
    FormType::Passacaglia,
    FormType::FantasiaAndFugue,
    FormType::CelloPrelude,
    FormType::Chaconne,
    FormType::GoldbergVariations,
};

constexpr SubjectCharacter kCharacters[] = {
    SubjectCharacter::Severe,
    SubjectCharacter::Playful,
    SubjectCharacter::Noble,
    SubjectCharacter::Restless,
};

// Every counterpoint rule that relates two voices sounding together, sorted by
// rule id. The geometry assertion below keeps this list honest.
constexpr const char* kVerticalRules[] = {
    "anti_parallel_perfect",  "battuta",
    "cross_relation",         "doubling_no_leading_tone",
    "doubling_no_seventh",    "hidden_parallel_fifth",
    "hidden_parallel_octave", "invertible_at_octave",
    "parallel_fifth",         "parallel_octave",
    "strong_beat_dissonance", "unprepared_dissonance",
    "vertical_dissonance",
};

// Every counterpoint rule that describes one voice on its own.
constexpr const char* kLinearRules[] = {
    "augmented_melodic", "consecutive_leaps",       "diminished_melodic",
    "tritone_melodic",   "leading_tone_resolution",
};

composer::RuleObservation observation(const std::string& rule_id, int total) {
  composer::RuleObservation result;
  result.rule_id = rule_id;
  result.total = total;
  result.gated = 0;
  result.exempted = total;
  return result;
}

// Every row marked settled, as (form, rule_id), in table order.
std::vector<std::pair<std::string, std::string>> settledRows() {
  std::size_t count = 0;
  const composer::CounterpointBudgetEntry* table = composer::counterpointBudgetTable(&count);
  std::vector<std::pair<std::string, std::string>> settled;
  for (std::size_t idx = 0; idx < count; ++idx) {
    if (table[idx].reason == composer::OpenReason::Accepted) {
      settled.emplace_back(formTypeToString(table[idx].form), table[idx].rule_id);
    }
  }
  return settled;
}

std::vector<std::string> closedRulesFor(FormType form) {
  std::vector<std::string> closed;
  for (const char* rule_id : kVerticalRules) {
    if (composer::counterpointRuleIsClosed(form, rule_id)) {
      closed.emplace_back(rule_id);
    }
  }
  return closed;
}

// ---------------------------------------------------------------------------
// The open-rule table itself
// ---------------------------------------------------------------------------

TEST(CounterpointBudgetTest, TableHoldsOnlyVerticalRulesInStrictOrder) {
  std::size_t count = 0;
  const composer::CounterpointBudgetEntry* table = composer::counterpointBudgetTable(&count);
  ASSERT_NE(table, nullptr);
  ASSERT_GT(count, 0u);

  for (std::size_t idx = 0; idx < count; ++idx) {
    const std::string rule_id = table[idx].rule_id == nullptr ? std::string() : table[idx].rule_id;
    SCOPED_TRACE(formTypeToString(table[idx].form));
    SCOPED_TRACE(rule_id);
    EXPECT_FALSE(rule_id.empty());
    // Gating a linear rule would describe nothing the composer chose, so no
    // linear rule may appear here even as an exception.
    EXPECT_EQ(composer::counterpointRuleGeometry(rule_id), composer::RuleGeometry::Vertical);
    // A rule the table opens but kVerticalRules omits would leave a hole in the
    // pinned closure sets below.
    EXPECT_TRUE(std::any_of(std::begin(kVerticalRules), std::end(kVerticalRules),
                            [&rule_id](const char* known) { return rule_id == known; }))
        << "rule is missing from the pinned vertical-rule list";
    if (idx == 0) {
      continue;
    }
    // Strict ordering by (form ordinal, rule_id) also rules out duplicates.
    const int previous_form = static_cast<int>(table[idx - 1].form);
    const int current_form = static_cast<int>(table[idx].form);
    const std::string previous_rule = table[idx - 1].rule_id;
    EXPECT_TRUE(previous_form < current_form ||
                (previous_form == current_form && previous_rule < rule_id))
        << "row " << idx << " breaks the (form, rule_id) ordering";
  }
}

TEST(CounterpointBudgetTest, SettledRowsArePinned) {
  // Written out literally so a row that stops being outstanding work has to be
  // argued for here rather than slipping in with the change that re-labels it.
  // Every row here is settled for a reason of one of two shapes. Either the
  // repair works and costs more than the fault -- the chorale prelude's
  // contrary-motion octave appears once over the whole request surface, at a
  // bass approach beat, and the re-aim that removes it leaves the dissonances
  // downstream of the displaced tone unprepared; the goldberg canon's doubled
  // leading tone goes away once the block chooser ranks it, but the only
  // doubling-free assignment it can reach is chromatic and pays cross relations
  // several times over. Or the repair has nothing to choose: the passacaglia's
  // two hidden classes all sit on beat anchors whose admissible tones, however
  // many, contain no parallel-free member, and both ways of widening that set
  // were measured to cost a conjunct melodic surface or the form's own gate.
  EXPECT_EQ(settledRows(), (std::vector<std::pair<std::string, std::string>>{
                               {"chorale_prelude", "anti_parallel_perfect"},
                               {"passacaglia", "hidden_parallel_fifth"},
                               {"passacaglia", "hidden_parallel_octave"},
                               {"goldberg_variations", "doubling_no_leading_tone"}}));
}

TEST(CounterpointBudgetTest, OutstandingRowCountOnlyEverFalls) {
  std::size_t count = 0;
  const composer::CounterpointBudgetEntry* table = composer::counterpointBudgetTable(&count);
  ASSERT_NE(table, nullptr);

  std::size_t outstanding = 0;
  for (std::size_t idx = 0; idx < count; ++idx) {
    if (table[idx].reason == composer::OpenReason::Unresolved) {
      ++outstanding;
    }
  }

  // RATCHET: this number may only ever be LOWERED, never raised. It counts the
  // rules a form still breaks and nobody has decided to live with, so lowering
  // it means a form was repaired and its row deleted, or a row was settled with
  // its reason recorded. Raising it means a form started breaking a rule it had
  // stopped breaking, and the fix belongs in that form rather than here.
  EXPECT_LE(outstanding, 81u) << "a vertical rule re-opened as outstanding work";
}

TEST(CounterpointBudgetTest, RuleListsMatchTheValidatorGeometryTable) {
  for (const char* rule_id : kVerticalRules) {
    SCOPED_TRACE(rule_id);
    EXPECT_EQ(composer::counterpointRuleGeometry(rule_id), composer::RuleGeometry::Vertical);
  }
  for (const char* rule_id : kLinearRules) {
    SCOPED_TRACE(rule_id);
    EXPECT_EQ(composer::counterpointRuleGeometry(rule_id), composer::RuleGeometry::Linear);
  }
}

TEST(CounterpointBudgetTest, LinearAndUnknownRulesAreNeverClosed) {
  for (FormType form : kShippedForms) {
    SCOPED_TRACE(formTypeToString(form));
    for (const char* rule_id : kLinearRules) {
      SCOPED_TRACE(rule_id);
      EXPECT_FALSE(composer::counterpointRuleIsClosed(form, rule_id));
    }
    EXPECT_FALSE(composer::counterpointRuleIsClosed(form, "no_such_rule"));
    EXPECT_FALSE(composer::counterpointRuleIsClosed(form, std::string()));
  }
}

TEST(CounterpointBudgetTest, ClosedRulesPerFormArePinned) {
  // Written out literally so any edit to the open-rule table shows up here as a
  // change of closure state rather than passing silently.
  // Both true-parallel classes close. The stretto refuses a canon configuration
  // that sounds one; the coda's cadence voicing is registered like any other
  // figuration so the seam into it is read as a hand-over rather than a rest;
  // and the bar-head escape ranks a sustain-window clash below the parallel
  // rather than vetoing on it. The two forms share one section builder.
  const std::vector<std::string> both_true_parallels_closed = {"doubling_no_seventh",
                                                               "parallel_fifth", "parallel_octave"};
  EXPECT_EQ(closedRulesFor(FormType::Fugue), both_true_parallels_closed);
  EXPECT_EQ(closedRulesFor(FormType::PreludeAndFugue), both_true_parallels_closed);
  // The pedal is written last against two settled manuals and ranks a hidden
  // perfect below a true one, so it steps onto the weaker approach instead of
  // keeping the parallel its three-tone band left it with; where the band runs
  // out entirely the middle manual takes the arrival.
  EXPECT_EQ(closedRulesFor(FormType::TrioSonata),
            (std::vector<std::string>{"doubling_no_seventh", "invertible_at_octave",
                                      "parallel_fifth", "parallel_octave"}));
  // Its arrivals are re-aimed over a bass pinned to one octave, and the window
  // for that re-aim widens to a passing dissonance rather than let a true
  // parallel ship; the cadential figure that pins the bass under its resolution
  // is chosen against the surface it produces. No octave reaches the upper pair
  // either, so the invertibility rule closes with them.
  EXPECT_EQ(
      closedRulesFor(FormType::ChoralePrelude),
      (std::vector<std::string>{"doubling_no_leading_tone", "doubling_no_seventh",
                                "invertible_at_octave", "parallel_fifth", "parallel_octave"}));
  // The fifth closes with the fantasia's, whose section builder this form
  // shares. The octave closes with it now that the free section's opening
  // rhetoric declares what it is: the gesture stated low and restated exactly an
  // octave below in a neighbouring voice is one line on two ranks, and the
  // validator checks the restatement note for note before reading the pair as
  // that one line rather than as two parts moving in octaves.
  EXPECT_EQ(closedRulesFor(FormType::ToccataAndFugue),
            (std::vector<std::string>{"doubling_no_seventh", "parallel_fifth", "parallel_octave"}));
  // The counter-figuration is written last against a settled variation and an
  // immutable ground, and reads both as one continuous line across the ground
  // cycles; where its band offers no admissible tone at all it holds the tone it
  // just sounded, since an oblique repeat can form no parallel. The variation's
  // own onsets are scrubbed against the ground at beat grain, and the cadential
  // suspension that rewrites one of them afterwards re-reads that same reference
  // instead of the bar head, which a ground stated in quarters moves three times
  // inside. Both true-parallel classes close; the seventh doubling does not,
  // and this is the only form where it stays open. The invertibility rule is
  // the parallel octave restricted to the adjacent upper pair, so it closes
  // with them: a texture that sounds no octave anywhere sounds none there.
  EXPECT_EQ(
      closedRulesFor(FormType::Passacaglia),
      (std::vector<std::string>{"invertible_at_octave", "parallel_fifth", "parallel_octave"}));
  // Its stretto reads four canon configurations and refuses one that sounds a
  // true parallel; the fill running up to that block is written before it so the
  // block has a preceding bar to be read against; the half-cadence bass and the
  // coda's inner voice rank the register of a tone whose pitch class is the
  // design value; and the sustained support leaves the chord once no triad tone
  // in the band would do.
  EXPECT_EQ(closedRulesFor(FormType::FantasiaAndFugue),
            (std::vector<std::string>{"doubling_no_seventh", "invertible_at_octave",
                                      "parallel_fifth", "parallel_octave"}));
  // Monophonic: every rule comparing two lines is closed permanently, and only
  // the two judged against the harmonic plan stay open.
  EXPECT_EQ(
      closedRulesFor(FormType::CelloPrelude),
      (std::vector<std::string>{
          "anti_parallel_perfect", "battuta", "cross_relation", "doubling_no_leading_tone",
          "doubling_no_seventh", "hidden_parallel_fifth", "hidden_parallel_octave",
          "invertible_at_octave", "parallel_fifth", "parallel_octave", "vertical_dissonance"}));
  // Its upper line is ranked against the ground before it ships, at every onset
  // the variation owns and at both ends of the cadential coda.
  EXPECT_EQ(closedRulesFor(FormType::Chaconne),
            (std::vector<std::string>{"battuta", "doubling_no_seventh", "invertible_at_octave",
                                      "parallel_fifth", "parallel_octave"}));
  // Its imitative blocks are chosen against the bass rather than repaired after
  // it, and the figuration between them is relieved arrival by arrival. The
  // choice ranks the two upper voices meeting on one pitch below the parallel
  // that avoiding the meeting would cost, which is what closes the octave.
  EXPECT_EQ(closedRulesFor(FormType::GoldbergVariations),
            (std::vector<std::string>{"doubling_no_seventh", "invertible_at_octave",
                                      "parallel_fifth", "parallel_octave"}));
}

// ---------------------------------------------------------------------------
// applyCounterpointBudget on a hand-built report
// ---------------------------------------------------------------------------

TEST(CounterpointBudgetTest, ClosedRuleWithAMatchFailsThePiece) {
  composer::ValidationReport report;
  report.observations.push_back(observation("doubling_no_seventh", 1));

  composer::applyCounterpointBudget(FormType::Fugue, &report);

  ASSERT_EQ(report.failures.size(), 1u);
  EXPECT_EQ(report.failures[0].rule_id, "doubling_no_seventh");
  EXPECT_EQ(report.failures[0].kind, FailKind::MusicalFail);
  // Routing the status is the caller's job, not the budget's.
  EXPECT_EQ(report.status, composer::ValidationStatus::Ok);
}

TEST(CounterpointBudgetTest, ClosedRuleWithoutAMatchAppendsNothing) {
  composer::ValidationReport report;
  report.observations.push_back(observation("doubling_no_seventh", 0));

  composer::applyCounterpointBudget(FormType::Fugue, &report);

  EXPECT_TRUE(report.failures.empty());
}

TEST(CounterpointBudgetTest, OpenAndLinearRulesNeverAppendHoweverOftenTheyMatch) {
  composer::ValidationReport report;
  report.observations.push_back(observation("hidden_parallel_octave", 500));
  report.observations.push_back(observation("strong_beat_dissonance", 500));
  report.observations.push_back(observation("tritone_melodic", 500));

  composer::applyCounterpointBudget(FormType::Fugue, &report);

  EXPECT_TRUE(report.failures.empty());
}

TEST(CounterpointBudgetTest, AppendsOneFailurePerClosedRuleAndPreservesExistingOnes) {
  composer::ValidationReport report;
  composer::ValidationFailure existing;
  existing.rule_id = "suspension_resolution_step_down";
  existing.kind = FailKind::StructuralFail;
  report.failures.push_back(existing);
  report.observations.push_back(observation("doubling_no_leading_tone", 3));
  report.observations.push_back(observation("doubling_no_seventh", 7));
  report.observations.push_back(observation("cross_relation", 9));

  // The chorale prelude closes both doubling rules and leaves cross_relation open.
  composer::applyCounterpointBudget(FormType::ChoralePrelude, &report);

  ASSERT_EQ(report.failures.size(), 3u);
  EXPECT_EQ(report.failures[0].rule_id, "suspension_resolution_step_down");
  EXPECT_EQ(report.failures[0].kind, FailKind::StructuralFail);
  EXPECT_EQ(report.failures[1].rule_id, "doubling_no_leading_tone");
  EXPECT_EQ(report.failures[2].rule_id, "doubling_no_seventh");
}

TEST(CounterpointBudgetTest, ASettledRowGatesExactlyLikeAnOutstandingOne) {
  // The reason is bookkeeping only: both kinds of row are open, so neither
  // closes a rule and neither can fail a piece.
  const std::string settled_rule = "anti_parallel_perfect";
  EXPECT_FALSE(composer::counterpointRuleIsClosed(FormType::ChoralePrelude, settled_rule));

  composer::ValidationReport report;
  report.observations.push_back(observation(settled_rule, 500));
  report.observations.push_back(observation("cross_relation", 500));

  composer::applyCounterpointBudget(FormType::ChoralePrelude, &report);

  EXPECT_TRUE(report.failures.empty());
}

TEST(CounterpointBudgetTest, NullReportIsANoOp) {
  composer::applyCounterpointBudget(FormType::Fugue, nullptr);
}

// ---------------------------------------------------------------------------
// The gate over the shipped request surface
// ---------------------------------------------------------------------------

// One request variation applied to a form/character pair.
struct RequestVariation {
  bool minor = false;
  DurationScale scale = DurationScale::Short;
  std::uint16_t target_bars = 0;
  std::uint32_t seed = 1;
};

std::vector<RequestVariation> requestVariations() {
  constexpr bool modes[] = {false, true};
  constexpr std::uint32_t seeds[] = {1, 3, 7};
  std::vector<RequestVariation> variations;
  for (bool minor : modes) {
    for (int length = 0; length < 3; ++length) {
      for (std::uint32_t seed : seeds) {
        RequestVariation variation;
        variation.minor = minor;
        variation.seed = seed;
        if (length == 0) {
          variation.scale = DurationScale::Short;
        } else if (length == 1) {
          variation.scale = DurationScale::Full;
        } else {
          // target_bars overrides the scale, so the scale carried here is inert.
          variation.scale = DurationScale::Short;
          variation.target_bars = 128;
        }
        variations.push_back(variation);
      }
    }
  }
  return variations;
}

CompositionRequest buildRequest(FormType form, SubjectCharacter character,
                                const RequestVariation& variation) {
  CompositionRequest request;
  request.form = form;
  request.character = character;
  request.key = {variation.minor ? Key::G : Key::C, variation.minor};
  request.scale = variation.scale;
  request.target_bars = variation.target_bars;
  request.seed = variation.seed;
  request.bpm = 100;
  return request;
}

void expectComposesClean(const CompositionRequest& request) {
  SCOPED_TRACE(formTypeToString(request.form));
  SCOPED_TRACE(subjectCharacterToString(request.character));
  SCOPED_TRACE(keyToString(request.key.tonic));
  SCOPED_TRACE(request.key.is_minor ? "minor" : "major");
  SCOPED_TRACE(durationScaleToString(request.scale));
  SCOPED_TRACE(request.target_bars);
  SCOPED_TRACE(request.seed);
  CompositionProduct product;
  ASSERT_EQ(compose(request, &product), CompositionStatus::Ok);
  EXPECT_TRUE(product.final_validation.failures.empty())
      << "first failure: "
      << (product.final_validation.failures.empty()
              ? std::string()
              : product.final_validation.failures.front().rule_id);
  EXPECT_EQ(product.final_validation.status, composer::ValidationStatus::Ok);
  EXPECT_FALSE(product.midi_bytes.empty());
}

TEST(CounterpointBudgetTest, GateIsOutputNeutralOverTheShippedRequestSurface) {
  const std::vector<RequestVariation> variations = requestVariations();
  ASSERT_EQ(variations.size(), 18u);
  std::vector<bool> variation_used(variations.size(), false);

  std::size_t rotation = 0;
  for (FormType form : kShippedForms) {
    for (SubjectCharacter character : kCharacters) {
      if (!composer::isFormCharacterCompatible(form, character)) {
        continue;
      }
      const std::size_t index = rotation % variations.size();
      variation_used[index] = true;
      ++rotation;
      expectComposesClean(buildRequest(form, character, variations[index]));

      // The configuration that exposed rules a narrower sample reported as
      // closed: minor mode at the maximum bar count on the first seed.
      RequestVariation exposing;
      exposing.minor = true;
      exposing.scale = DurationScale::Short;
      exposing.target_bars = 128;
      exposing.seed = 1;
      expectComposesClean(buildRequest(form, character, exposing));
    }
  }

  EXPECT_EQ(rotation, 37u) << "the compatible form/character cross changed size";
  for (std::size_t idx = 0; idx < variation_used.size(); ++idx) {
    EXPECT_TRUE(variation_used[idx]) << "request variation " << idx << " was never exercised";
  }
}

}  // namespace
}  // namespace bach::application
